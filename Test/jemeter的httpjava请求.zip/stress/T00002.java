/*package com.test.stress;

import java.util.HashMap;
import java.util.Map;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.test.bean.ObjectToJsonTool;
import com.test.util.CaseUtil;
import com.test.util.InforTransferTool;
import com.test.util.XMTool;

public class T00002 extends AbstractJavaSamplerClient {
	static String reqContent;
	static String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCiuEewLOWgmy3tw1qnUhky2hAGMmvE9/8pxaUUNfGLXRXnALjCx1N7qW1MzIYFt9R9XAaCE2Gli8tlACHAL4VjZHSccjhRtrJFf7zlUFN6tU20Mr40bRRsccd+A5boAVtHViJNpsUZiRYN/9AQ23GIHGU9AJXljo6uiLZS3Vlu+QIDAQAB";
	static String privateKey_xm = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALDX9xlH/bNyvRh2396aixV2Reo9Huu26Y55sW+ynucdefU4370+K+hf+UWOSPgQFQ7nW9fRnJ7P1lcnJcsYIn2rZ73g7YKIO64BB6dXg1nnB47MlvbKgyUOnR9HZ/7HQ0VRKRG5lm2d0+Aptm+NJ3SZcqOz93ZpW6OqcF0pMFrXAgMBAAECgYARA2X5X6yvs+0vSlh1UQbqdKt7QpAT+0/y7hA8/8E72OEfz23vBekxfPI9V9f7TYjJG0cBt1/LA5HKZrDDHjpLFdw8NJ7RAB+9bU7dBmnCJXPJzO9mlkGhSWi/MvtGrjZ6f5R0tauZ9WCynCdoKQL7hNQ6h2+Go6Sm6HyOGvQ5mQJBANl8FHzXMnYj3US6jhLuXLaKlWj3la4jbzl4hc9xRXHS63yScWBHZfrGPc07D3frhEtAGG4oqhZz8I8zFYhQEtMCQQDQKWAHGyjunedZa/vcPeoEMXvGkCw4LYs9IAb8L/zLqt8BQNI0L2pXyjGSr5Pf/4p7RtSyLJZbIrasfzwyye1tAkEApLhyt/8xjAMr4pM9ah84/1TFRwRGTOcvpaKgDnbnNweeLfKohlhtZ9tgEaIK3DP4NhpspnqMIIddisgRJfYn2wJBAJmij/9uqk1DOecj7eXlxHyH0SUCb8CezK+2nbEv8dKYMLOKFhryC/jzgJcVA31F6/2Ej6NZiTeGbXDvD40kwBkCQD1eb9tEilkBgcGv4gelSVOrKiuv9RjQIPepnAxKUP6sIU7CQ0dcdDlIeAcsJumWMiTWGnCP3quQ50ENED3XunY=";

	public static void main(String[] args) {
		T00002 test = new T00002();

		Arguments params = new Arguments();
		params.addArgument("Url",
				"http://localhost:8081/AndroidServer/list3.do");
		params.addArgument("param", "");

		JavaSamplerContext arg0 = new JavaSamplerContext(params);

		test.setupTest(arg0);
		test.runTest(arg0);
		test.teardownTest(arg0);

	}

	public void setupTest(JavaSamplerContext arg0) {

	}

	@Override
	public SampleResult runTest(JavaSamplerContext arg0) {
		// TODO Auto-generated method stub
		// 创建SampleResult对象，用于记录执行结果的状态，并返回
		SampleResult results = new SampleResult();
		// 获取JMeter中输入的用户参数
		String authUrl = arg0.getParameter("Url");
		String reqCont = arg0.getParameter("param");
		String data = encrypt(reqCont);// 加密数据
		results.setSamplerData("请求:" + reqCont);

		try {
			results.sampleStart();// jmeter 开始统计响应时间标记
			String rspCont = InforTransferTool.doPost(authUrl, data);

			// 通过下面的操作就可以将被测方法的响应输出到Jmeter的察看结果树中的响应数据里面了。
			String resultData = dencrypt(rspCont);
			System.out.println("***" + resultData);
			if (resultData != null && resultData.length() > 0) {
				results.setResponseData("响应：" + resultData, null);

				results.setDataType(SampleResult.TEXT);
			}

			results.setSuccessful(true);

			// 被测对象调用
		} catch (Throwable e) {
			results.setSuccessful(false);
			e.printStackTrace();
		} finally {
			results.sampleEnd();// jmeter 结束统计响应时间标记
		}
		return results;

	}

	// 设置传入的参数，可以设置多个，已设置的参数会显示到Jmeter的参数列表中
	public Arguments getDefaultParameters() {
		reqContent = init();
		Arguments args = new Arguments();
		args.addArgument("Url", "http://localhost:8081/AndroidServer/list3.do");
		args.addArgument("param", reqContent);

		return args;
	}

	*//**
	 * 执行runTest()方法后会调用此方法,可放一些资源释放代码
	 *//*
	@Override
	public void teardownTest(JavaSamplerContext context) {

		// 关闭连接

	}

	public static String init() {

		String caseId = "xm_00002_001";
		Map<String, HashMap<String, String>> testcase = CaseUtil
				.getCases("00002");
		// 创建gson对象
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		// 按案例编号获取map数据
		Map<String, String> map = CaseUtil.getCaseByCases(caseId, testcase);

		// 生成请求报文
		String reqCont = ObjectToJsonTool.getReqContent(caseId, gson, map);

		return reqCont;

	}

	public static String encrypt(String reqCont) {

		// 加密
		String data = XMTool.encrypt(reqCont, publicKey, privateKey_xm);

		return data;
	}

	public static String dencrypt(String data) {

		// 解密
		String result = XMTool.dencrypt(data, publicKey, privateKey_xm);

		return result;
	}
}*/